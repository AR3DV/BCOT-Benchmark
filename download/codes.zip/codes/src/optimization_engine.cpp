#include "optimization_engine.h"
#include <opencv2/opencv.hpp>
#include <algorithm>
#include <iostream>

using namespace std;
using namespace cv;

OptimizationEngine::OptimizationEngine(int width, int height)
{
    renderingEngine = RenderingEngine::Instance();
    
    SDT2D = new SignedDistanceTransform2D(8.0f);
    
    this->width = width;
    this->height = height;
}

OptimizationEngine::~OptimizationEngine() 
{
    delete SDT2D;
}

void OptimizationEngine::minimize(vector<Mat>& imagePyramid, vector<Object3D*>& objects, int runs, int iterNum, Matx44f matTrans12, Matx44f matTrans21)
{
	if (iterNum < 5) {
		runIteration(objects, imagePyramid, 2, matTrans12, matTrans21);
	}
	if (iterNum > 4 && iterNum < 7) {
		runIteration(objects, imagePyramid, 1, matTrans12, matTrans21);
	}
	if (iterNum > 6) {
		runIteration(objects, imagePyramid, 0, matTrans12, matTrans21);
	}
}

void OptimizationEngine::runIteration(vector<Object3D*>& objects, const vector<Mat>& imagePyramid, int level, cv::Matx44f matTrans12, cv::Matx44f matTrans21)
{
    Rect roi, roi_;
    Mat mask, depth, depthInv, sdt, xyPos;
    Mat croppedMask, croppedDepth, croppedDepthInv;
	Mat croppedMask_1, croppedMask_2, sdt_1, sdt_2;
	int levelCopy = level;
    
    renderingEngine->setLevel(level);
    
    int numInitialized = 0;
    
    // increase the image pyramid level until the area of the 2D bounding box
    // of every object is greater than 3000 pixels in the image
    for(int o = 0; o < objects.size(); o++)
    {
        if(objects[o]->isInitialized())
        {
            roi = compute2DROI(objects[o], Size(width/pow(2, level), height/pow(2, level)), 8);
            numInitialized++;
        }
    }
    
    renderingEngine->setLevel(level);
    renderingEngine->renderSilhouette(vector<Model*>(objects.begin(), objects.end()), GL_FILL);
    
    // download the depth buffer
	// slow way.
    //depth = renderingEngine->downloadFrame(RenderingEngine::DEPTH);

	//fast way
	roi_ = cv::Rect(roi.x, roi.y, (roi.width / 4) * 4, (roi.height / 4) * 4);
	Mat depthRoi = renderingEngine->downloadFrame(RenderingEngine::DEPTH, roi_);
	depth = cv::Mat::zeros(renderingEngine->height, renderingEngine->width, CV_32FC1);
	depthRoi.copyTo(depth(roi_));
    
    // if more than one object is initialized, download the common silhouette
    // mask required for occlusion detection
    if(numInitialized > 1)
    {
        mask = renderingEngine->downloadFrame(RenderingEngine::MASK);
    }
    else // otherwise for a single object the mask is equal to the depth buffer
    {
        mask = depth;
    }
    
    for(int o = 0; o < objects.size(); o++)
    {
        if(objects[o]->isInitialized())
        {
            // compute the 2D region of interest containing the silhouette of the current object
            roi = compute2DROI(objects[o], Size(width/pow(2, level), height/pow(2, level)), 8);
            
            if(roi.area() == 0)
            {
                continue;
            }
            
            renderingEngine->renderSilhouette(objects[o], GL_FILL, true);

			// slow way
            //depthInv = renderingEngine->downloadFrame(RenderingEngine::DEPTH);

			// fast way
			roi_ = cv::Rect(roi.x, roi.y, (roi.width / 4) * 4, (roi.height / 4) * 4);
			Mat depthInvRoi = renderingEngine->downloadFrame(RenderingEngine::DEPTH, roi_);
			depthInv = cv::Mat::ones(renderingEngine->height, renderingEngine->width, CV_32FC1);
			depthInvRoi.copyTo(depthInv(roi_));

            // crop the images wrt to the 2D roi
            croppedMask = mask(roi).clone();
            croppedDepth = depth(roi).clone();
            croppedDepthInv = depthInv(roi).clone();
            
            int m_id = (numInitialized <= 1) ? -1 : objects[o]->getModelID();
            

            // compute the 2D signed distance transform of the silhouette
            SDT2D->computeTransform(croppedMask, sdt, xyPos, 8, m_id);

			Rect roi_11(0, 0, roi.width, roi.height / 2);
			Rect roi_12(0, roi.height / 2, roi.width, roi.height / 2);

			cv::Matx44f K = renderingEngine->getCalibrationMatrix();
			float zn = renderingEngine->getZNear();
			float zf = renderingEngine->getZFar();
            

			// the hessian approximation
			Matx66f wJTJ, wJTJ_1, wJTJ_2;
			// the gradient
			Matx61f JT, JT_1, JT_2;
			// weight of color
			float wColor, wColor1, wColor2;
			// compute the Jacobian terms (i.e. the gradient and the hessian approx.) needed for the Gauss-Newton step
			parallel_computeJacobians(objects[o], imagePyramid[level], croppedDepth, croppedDepthInv, sdt, xyPos, roi, croppedMask, m_id, level, wJTJ, JT, wColor, roi.height, matTrans12);
			// update the pose by computing the Gauss-Newton step
			applyStepGaussNewton(objects[o], wJTJ, JT, matTrans12, matTrans21);

        }
    }
}

void OptimizationEngine::parallel_computeJacobians(Object3D* object, const Mat& frame, const Mat& depth, const Mat& depthInv, const Mat& sdt, const Mat& xyPos, const Rect& roi, const cv::Mat& mask, int m_id, int level, 
	Matx66f& wJTJ, Matx61f &JT, float &wColor, int threads, Matx44f matTrans)
{
    float zNear = renderingEngine->getZNear();
    float zFar = renderingEngine->getZFar();
    Matx33f K = renderingEngine->getCalibrationMatrix().get_minor<3, 3>(0, 0);
    
    JT = Matx61f::zeros();
    wJTJ = Matx66f::zeros();
	wColor = 0;
    
    vector<Matx61f> JTCollection(threads);
    vector<Matx66f> wJTJCollection(threads);
	vector<float> wColorCollection(threads);
    
    parallel_for_(cv::Range(0, threads), Parallel_For_computeJacobiansGN(object->getTCLCHistograms(), frame, sdt, xyPos, depth, depthInv, K, zNear, zFar, roi, mask, m_id, level, wJTJCollection, JTCollection, wColorCollection, threads, matTrans));
    
    for(int i = 0; i < threads; i++)
    {
        JT += JTCollection[i];
        wJTJ += wJTJCollection[i];
    }
    
    // copy the top right triangular matrix into the bottom left triangle
    for(int i = 0; i < wJTJ.rows; i++)
    {
        for(int j = i+1; j < wJTJ.cols; j++)
        {
            wJTJ(j, i) = wJTJ(i, j);
        }
    }

	for (int i = 0; i < threads; i++)
	{
		wColor += wColorCollection[i];
	}
}

Rect OptimizationEngine::compute2DROI(Object3D* object, const cv::Size& maxSize, int offset)
{
    // PROJECT THE 3D BOUNDING BOX AS 2D ROI
    Rect boundingRect;
    vector<Point2f> projections;
    
    renderingEngine->projectBoundingBox(object, projections, boundingRect);
    
    if(boundingRect.x >= maxSize.width || boundingRect.y >= maxSize.height
       || boundingRect.x + boundingRect.width <= 0 || boundingRect.y + boundingRect.height <= 0)
    {
        return Rect(0, 0, 0, 0);
    }
    
    // CROP THE ROI AROUND THE SILHOUETTE
    Rect roi = Rect(boundingRect.x - offset, boundingRect.y - offset, boundingRect.width + 2*offset, boundingRect.height + 2*offset);
    
    if(roi.x < 0)
    {
        roi.width += roi.x;
        roi.x = 0;
    }
    
    if(roi.y < 0)
    {
        roi.height += roi.y;
        roi.y = 0;
    }
    
    if(roi.x+roi.width > maxSize.width) roi.width = maxSize.width - roi.x;
    if(roi.y+roi.height > maxSize.height) roi.height = maxSize.height - roi.y;
    
    return roi;
}

void OptimizationEngine::applyStepGaussNewton(Object3D* object, const Matx66f& wJTJ, const Matx61f& JT, Matx44f matxTrans12, Matx44f matxTrans21)
{
    // Gauss-Newton step in se3
	// NOTE: the rotation is [0],[1],[2]; translation is [3],[4],[5]
    Matx61f delta_xi = -wJTJ.inv(DECOMP_CHOLESKY)*JT;
	object->delta_xi_Inobj = delta_xi;
	object->wJTJ_Inobj = wJTJ;
	object->JT_Inobj = JT;
}
