#include "model.h"
#include "tclc_histograms.h"

#include <limits>

#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/mesh.h>
#include <assimp/postprocess.h>

using namespace std;
using namespace cv;

Model::Model(const string modelFilename, float tx, float ty, float tz, float alpha, float beta, float gamma, float scale)
{
    m_id = 0;
    
    initialized = false;
    
    buffersInitialsed = false;
    
    T_i = Transformations::translationMatrix(tx, ty, tz)
    *Transformations::rotationMatrix(alpha, Vec3f(1, 0, 0))
    *Transformations::rotationMatrix(beta, Vec3f(0, 1, 0))
    *Transformations::rotationMatrix(gamma, Vec3f(0, 0, 1))
    *Matx44f::eye();
    
    T_cm = T_i;
    
    scaling = scale;
    
    T_n = Matx44f::eye();
    
    hasNormals = false;
    
    vertexBuffer = QOpenGLBuffer(QOpenGLBuffer::VertexBuffer);
    normalBuffer = QOpenGLBuffer(QOpenGLBuffer::VertexBuffer);
    indexBuffer = QOpenGLBuffer(QOpenGLBuffer::IndexBuffer);
    
    //loadModel(modelFilename);
	loadModel2(modelFilename);
}


Model::~Model()
{
    vertices.clear();
    normals.clear();
    
    indices.clear();
    offsets.clear();
    
    if(buffersInitialsed)
    {
        vertexBuffer.release();
        vertexBuffer.destroy();
        normalBuffer.release();
        normalBuffer.destroy();
        
        indexBuffer.release();
        indexBuffer.destroy();
    }
}

void Model::initBuffers()
{
    vertexBuffer.create();
    vertexBuffer.setUsagePattern(QOpenGLBuffer::StaticDraw);
    vertexBuffer.bind();
    vertexBuffer.allocate(vertices.data(), (int)vertices.size() * sizeof(Vec3f));
    
    normalBuffer.create();
    normalBuffer.setUsagePattern(QOpenGLBuffer::StaticDraw);
    normalBuffer.bind();
    normalBuffer.allocate(normals.data(), (int)normals.size() * sizeof(Vec3f));
    
    indexBuffer.create();
    indexBuffer.setUsagePattern(QOpenGLBuffer::StaticDraw);
    indexBuffer.bind();
    indexBuffer.allocate(indices.data(), (int)indices.size() * sizeof(int));
    
    buffersInitialsed = true;
}


void Model::initialize()
{
    initialized = true;
}


bool Model::isInitialized()
{
    return initialized;
}


void Model::draw(QOpenGLShaderProgram *program, GLint primitives)
{
    vertexBuffer.bind();
    program->enableAttributeArray("aPosition");
    program->setAttributeBuffer("aPosition", GL_FLOAT, 0, 3, sizeof(Vec3f));
    
    normalBuffer.bind();
    program->enableAttributeArray("aNormal");
    program->setAttributeBuffer("aNormal", GL_FLOAT, 0, 3, sizeof(Vec3f));
    
    program->enableAttributeArray("aColor");
    program->setAttributeBuffer("aColor", GL_UNSIGNED_BYTE, 0, 3, sizeof(Vec3b));
    
    indexBuffer.bind();
    
    for (uint i = 0; i < offsets.size() - 1; i++) {
        GLuint size = offsets.at(i + 1) - offsets.at(i);
        GLuint offset = offsets.at(i);
        
        glDrawElements(primitives, size, GL_UNSIGNED_INT, (GLvoid*)(offset*sizeof(GLuint)));
    }
}


Matx44f Model::getPose()
{
    return T_cm;
}

void Model::setPose(const Matx44f &T_cm)
{
    this->T_cm = T_cm;
}

void Model::setInitialPose(const Matx44f &T_cm)
{
    T_i = T_cm;
}

Matx44f Model::getNormalization()
{
    return T_n;
}


Vec3f Model::getLBN()
{
    return lbn;
}

Vec3f Model::getRTF()
{
    return rtf;
}

float Model::getScaling() {
    
    return scaling;
}


vector<Vec3f> Model::getVertices()
{
    return vertices;
}

int Model::getNumVertices()
{
    return (int)vertices.size();
}


int Model::getModelID()
{
    return m_id;
}


void Model::setModelID(int i)
{
    m_id = i;
}


void Model::reset()
{
    initialized = false;
    
    T_cm = T_i;
}


void Model::loadModel(const string modelFilename)
{
    Assimp::Importer importer;
    
    const aiScene* scene = importer.ReadFile(modelFilename, aiProcessPreset_TargetRealtime_Fast);
    
    aiMesh *mesh = scene->mMeshes[0];
    
    hasNormals = mesh->HasNormals();
    
    float inf = numeric_limits<float>::infinity();
    lbn = Vec3f(inf, inf, inf);
    rtf = Vec3f(-inf, -inf, -inf);

	// numVertices here is bigger than .obj model? why?
	// but should not effect the result.
	//std::cout << mesh->mNumVertices << std::endl;
	//std::cout << mesh->mNumFaces << std::endl;
    
    for(int i = 0; i < mesh->mNumFaces; i++)
    {
        aiFace f = mesh->mFaces[i];
        
        indices.push_back(f.mIndices[0]);
        indices.push_back(f.mIndices[1]);
        indices.push_back(f.mIndices[2]);
		faces.push_back(Face(f.mIndices[0], f.mIndices[1], f.mIndices[2]));
    }
    
    for(int i = 0; i < mesh->mNumVertices; i++)
    {
        aiVector3D v = mesh->mVertices[i];
        
        Vec3f p(v.x, v.y, v.z);
        
        // compute the 3D bounding box of the model
        if (p[0] < lbn[0]) lbn[0] = p[0];
        if (p[1] < lbn[1]) lbn[1] = p[1];
        if (p[2] < lbn[2]) lbn[2] = p[2];
        if (p[0] > rtf[0]) rtf[0] = p[0];
        if (p[1] > rtf[1]) rtf[1] = p[1];
        if (p[2] > rtf[2]) rtf[2] = p[2];
        
        vertices.push_back(p);
    }
    
    if(hasNormals)
    {
        for(int i = 0; i < mesh->mNumVertices; i++)
        {
            aiVector3D n = mesh->mNormals[i];
            
            Vec3f vn = Vec3f(n.x, n.y, n.z);
            
            normals.push_back(vn);
        }

    }
    
    offsets.push_back(0);
    offsets.push_back(mesh->mNumFaces*3);

	//std::cout << normals.size() << std::endl;
    
    // the center of the 3d bounding box
    Vec3f bbCenter = (rtf + lbn)/2;
    
    // compute a normalization transform that moves the object to the center of its bounding box and scales it according to the prescribed factor
    //T_n = Transformations::scaleMatrix(scaling)*Transformations::translationMatrix(-bbCenter[0], -bbCenter[1], -bbCenter[2]);
    
    //T_n = Transformations::scaleMatrix(scaling);
}

void Model::loadModel2(const string modelFilename)
{
	FILE *file = NULL;

	/* open the file */
	const char *filename = modelFilename.c_str();
	file = fopen(filename, "r");
	if (!file) {
		fprintf(stderr, "Cannot open data file \"%s\".\n", filename);
		exit(1);
	}

	float vcoordinates[3]; /* coordinates of a vertice  */
	char buf[128];         /* line buffer */
	int v[3], n[3], t[3];  /* v, vn, vt buffer of a face */

						   /* pass through the file, read vertice and faces */
	while (fscanf(file, "%s", buf) != EOF) {
		switch (buf[0]) {
		case 'v':               /* v, vn, vt */
			switch (buf[1]) {
			case '\0':          /* vertex */
				fscanf(file, "%f %f %f", &vcoordinates[0], &vcoordinates[1], &vcoordinates[2]);
				vertices.push_back(cv::Vec3f(vcoordinates[0], vcoordinates[1], vcoordinates[2]));
				break;
			case 'n':           /* normal */
				fgets(buf, sizeof(buf), file);
				break;
			case 't':           /* texcoord */
				fgets(buf, sizeof(buf), file);
				break;
			}
			break;
		case 'f':               /* face */
			fscanf(file, "%s", buf);
			/* can be one of %d, %d//%d, %d/%d, %d/%d/%d %d//%d */
			if (strstr(buf, "//")) {
				/* v//n */
				sscanf(buf, "%d//%d", &v[0], &n[0]);
				fscanf(file, "%d//%d", &v[1], &n[1]);
				fscanf(file, "%d//%d", &v[2], &n[2]);
				faces.push_back(Face(v[0] - 1, v[1] - 1, v[2] - 1));
				while (fscanf(file, "%d//%d", &v[0], &n[0]) > 0 &&
					fscanf(file, "%d//%d", &v[1], &n[1]) > 0 &&
					fscanf(file, "%d//%d", &v[2], &n[2]) > 0) {
					faces.push_back(Face(v[0] - 1, v[1] - 1, v[2] - 1));
				}
			}
			else if (sscanf(buf, "%d/%d/%d", &v[0], &t[0], &n[0]) == 3) {
				/* v/t/n */
				fscanf(file, "%d/%d/%d", &v[1], &t[1], &n[1]);
				fscanf(file, "%d/%d/%d", &v[2], &t[2], &n[2]);
				faces.push_back(Face(v[0] - 1, v[1] - 1, v[2] - 1));
				while (fscanf(file, "%d/%d/%d", &v[0], &t[0], &n[0]) > 0 &&
					fscanf(file, "%d/%d/%d", &v[1], &t[1], &n[1]) > 0 &&
					fscanf(file, "%d/%d/%d", &v[2], &t[2], &n[2]) > 0) {
					faces.push_back(Face(v[0] - 1, v[1] - 1, v[2] - 1));
				}
			}
			else if (sscanf(buf, "%d/%d", &v[0], &t[0]) == 2) {
				/* v/t */
				fscanf(file, "%d/%d", &v[1], &t[1]);
				fscanf(file, "%d/%d", &v[2], &t[2]);
				faces.push_back(Face(v[0] - 1, v[1] - 1, v[2] - 1));
				while (fscanf(file, "%d/%d", &v[0], &t[0]) > 0 &&
					fscanf(file, "%d/%d", &v[1], &t[1]) > 0 &&
					fscanf(file, "%d/%d", &v[2], &t[2]) > 0) {
					faces.push_back(Face(v[0] - 1, v[1] - 1, v[2] - 1));
				}
			}
			else {
				/* v */
				sscanf(buf, "%d", &v[0]);
				fscanf(file, "%d", &v[1]);
				fscanf(file, "%d", &v[2]);
				faces.push_back(Face(v[0] - 1, v[1] - 1, v[2] - 1));
				while (fscanf(file, "%d", &v[0]) > 0 &&
					fscanf(file, "%d", &v[1]) > 0 &&
					fscanf(file, "%d", &v[2]) > 0) {
					faces.push_back(Face(v[0] - 1, v[1] - 1, v[2] - 1));
				}
			}
			break;

		default:
			/* eat up rest of line */
			fgets(buf, sizeof(buf), file);
			break;
		}
	}
	// std::cout<<"mesh vertices size: "<<triMesh.vertices.size()<<std::endl;
	// std::cout<<"mesh faces size: "<<triMesh.faces.size()<<std::endl;
	
	compute_normals();

	float inf = numeric_limits<float>::infinity();
	lbn = Vec3f(inf, inf, inf);
	rtf = Vec3f(-inf, -inf, -inf);

	for (int i = 0; i < faces.size(); i++) {
		Face f = faces[i];
		indices.push_back(f[0]);
		indices.push_back(f[1]);
		indices.push_back(f[2]);
	}

	for (int i = 0; i < vertices.size(); i++) {

		Vec3f p = vertices[i];

		// compute the 3D bounding box of the model
		if (p[0] < lbn[0]) lbn[0] = p[0];
		if (p[1] < lbn[1]) lbn[1] = p[1];
		if (p[2] < lbn[2]) lbn[2] = p[2];
		if (p[0] > rtf[0]) rtf[0] = p[0];
		if (p[1] > rtf[1]) rtf[1] = p[1];
		if (p[2] > rtf[2]) rtf[2] = p[2];
	}

	offsets.push_back(0);
	offsets.push_back(faces.size() * 3);

	// the center of the 3d bounding box
	Vec3f bbCenter = (rtf + lbn) / 2;

	//std::cout << vertices.size() << std::endl;
	//std::cout << normals.size() << std::endl;
	//std::cout << "load model done." << std::endl;
}

void Model::compute_normals() {
	if (normals.size() == vertices.size())
		return;

	if (faces.empty()) {
		//Logger::Log(LogLv::Warning, "Model has no faces.");
		return;
	}

	// compute normals from faces
	normals.clear();
	normals.resize(vertices.size());
	for (size_t i = 0; i < faces.size(); ++i) {
		const Face & face = faces[i];
		const cv::Vec3f & p0 = vertices[face[0]];
		const cv::Vec3f & p1 = vertices[face[1]];
		const cv::Vec3f & p2 = vertices[face[2]];

		cv::Vec3f a = p0 - p1, b = p1 - p2, c = p2 - p0;
		float L2a = a.dot(a);
		float L2b = b.dot(b);
		float L2c = c.dot(c);
		if (!L2a || !L2b || !L2c)
			continue;

		cv::Vec3f facenormal = a.cross(b);
		normals[face[0]] += facenormal / (L2a*L2c);
		normals[face[1]] += facenormal / (L2b*L2a);
		normals[face[2]] += facenormal / (L2c*L2b);
	}

	// normalize to unit vector
	for (size_t i = 0; i < vertices.size(); ++i) {
		normals[i] = normalize(normals[i]);
	}

}