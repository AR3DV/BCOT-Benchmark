#ifndef OPTIMIZATION_ENGINE
#define OPTIMIZATION_ENGINE

#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/calib3d.hpp>

#include "rendering_engine.h"
#include "signed_distance_transform2d.h"
#include "tclc_histograms.h"
#include "object3d.h"
#include <omp.h>

using namespace cv;
using namespace std;

/**
 *  This class implements an iterative Gauss-Newton optimization strategy for
 *  minimizing the region-based cost function with respect to the 6DOF
 *  pose of multiple rigid 3D objects on the basis of tclc-histograms
 *  for pixel-wise posterior segmentation of a camera frame.
 */
class OptimizationEngine
{
public:
    /**
     *  Constructor of the optimization engine, that create a signed
     *  distance transform object for internal use.
     *
     *  @param width  The width in pixels of the camera frame at full resolution.
     *  @param height  The height in pixels of the camera frame at full resolution.
     */
    OptimizationEngine(int width, int height);
    
    ~OptimizationEngine();

    /**
     *  Performs an hierachical iterative Gauss-Newton pose optimization
     *  for multiple 3D objects based on a region-based cost fuction. The
     *  implementation is parallelized on the CPU and uses the GPU only
     *  for rendering the models with OpenGL. Given a coarse to fine image
     *  pyramid (with at least 3 levels, created with a scaling factor of 2)
     *  of the current camera frame, the poses of all provided 3D objects
     *  that have been initialized beforehand will be refined.
     *
     *  @param  imagePyramid A coarse to fine image pyramid of the camera frame showing the objects in question (at least 3 levels, RGB, uchar).
     *  @param  objects A collection 3d objects of which the poses are supposed to be optimized.
     *  @param  runs A factor specifiyng how many times the default number of iterations per level are supposed to be performed (default = 1).
     */
    void minimize(std::vector<cv::Mat> &imagePyramid, std::vector<Object3D*> &objects, int runs = 1, int iterNum = 0, Matx44f matTrans12 = Matx44f::eye(), Matx44f matTrans21 = Matx44f::eye());

	cv::Rect compute2DROI(Object3D *object, const cv::Size &maxSize, int offset);

private:
    static OptimizationEngine *instance;
    
    RenderingEngine *renderingEngine;
    
    SignedDistanceTransform2D *SDT2D;
    
    int width;
    int height;
    
    void runIteration(std::vector<Object3D*> &objects, const std::vector<cv::Mat> &imagePyramid, int level, cv::Matx44f matTrans12 = cv::Matx44f::eye(), cv::Matx44f matTrans21 = cv::Matx44f::eye());
	void parallel_computeJacobians(Object3D *object, const cv::Mat &frame, const cv::Mat &depth, const cv::Mat &depthInv, const cv::Mat &sdt, const cv::Mat &xyPos, const cv::Rect &roi, const cv::Mat &mask, int m_id, int level, 
		cv::Matx66f &wJTJ, cv::Matx61f &JT, float &wColor, int threads, Matx44f matTrans = Matx44f::eye());
    
    void applyStepGaussNewton(Object3D *object, const cv::Matx66f &wJTJ, const cv::Matx61f &JT, Matx44f matxTrans12 = Matx44f::eye(), Matx44f matxTrans21 = Matx44f::eye());
	
};


/**
 *  This class extends the OpenCV ParallelLoopBody for efficiently parallelized
 *  computations. Within the corresponding for loop, the Jacobian terms required for
 *  the Gauss-Newton pose update step are computed for a single object.
 */
class Parallel_For_computeJacobiansGN: public cv::ParallelLoopBody
{
private:
    uchar *frameData, *maskData, *initializedData;
    
    float *histogramsFGData, *histogramsBGData, *sdtData, *depthData, *depthInvData, *K_invData;
    
    int *xyPosData;
    
    cv::Mat localFG, localBG, overallUG;
    
    std::vector<cv::Point3i> centersIDs;
    
    int numHistograms, radius2, upscale, numBins, binShift, fullWidth, fullHeight, _m_id;
    
    float _fx, _fy, _zNear, _zFar, _cx, _cy;
    
    bool maskAvailable;
    
    cv::Rect _roi;
    
    cv::Matx33f K_inv;
    
    cv::Matx66f *_wJTJCollection;
    cv::Matx61f *_JTCollection;
	float* _wColorCollection;

	Matx44f _matTrans;
	Matx44f _matTransInv;

    int _threads;
	int _level;
    
public:
    Parallel_For_computeJacobiansGN(TCLCHistograms *tclcHistograms, const cv::Mat &frame, const cv::Mat &sdt, const cv::Mat &xyPos, const cv::Mat &depth, const cv::Mat &depthInv, const cv::Matx33f &K, float zNear, float zFar, 
		const cv::Rect &roi, const cv::Mat &mask, int m_id, int level, std::vector<cv::Matx66f> &wJTJCollection, std::vector<cv::Matx61f> &JTCollection, std::vector<float> &wColorCollection, int threads, Matx44f matTrans)
    {
        frameData = frame.data;
        
        localFG = tclcHistograms->getLocalForegroundHistograms();
        localBG = tclcHistograms->getLocalBackgroundHistograms();
        
        histogramsFGData = (float*)localFG.ptr<float>();
        histogramsBGData = (float*)localBG.ptr<float>();
        
        centersIDs = tclcHistograms->getCentersAndIDs();
        
        initializedData = tclcHistograms->getInitialized().data;
        
        numHistograms = (int)centersIDs.size();
        
        int radius = tclcHistograms->getRadius();
        
        radius2 = radius*radius;
        
        upscale = pow(2, level);
        
        numBins = tclcHistograms->getNumBins();
        
        binShift = 8 - log(numBins)/log(2);
        
        fullWidth = frame.cols;
        fullHeight = frame.rows;
        
        sdtData = (float*)sdt.ptr<float>();
        xyPosData = (int*)xyPos.ptr<int>();
        
        depthData = (float*)depth.ptr<float>();
        depthInvData = (float*)depthInv.ptr<float>();
        
        maskAvailable = false;
        if(m_id > 0)
        {
            maskData = (uchar*)mask.ptr<uchar>();
            maskAvailable = true;
            _m_id = m_id;
        }
        
        K_inv = K.inv();
        K_invData = K_inv.val;
        
        _fx = K(0, 0);
        _fy = K(1, 1);
		_cx = K(0, 2);
		_cy = K(1, 2);
        
        _zNear = zNear;
        _zFar = zFar;
        
        _roi = roi;
        
        _wJTJCollection = wJTJCollection.data();
        _JTCollection = JTCollection.data();
		_wColorCollection = wColorCollection.data();
		_matTrans = matTrans;
		_matTransInv = _matTrans.inv();
        
		_level = level;
        _threads = threads;
    }
    
    bool isOccluded (int idx, float dist, float d) const
    {
        if(dist > 0)
        {
            uchar mVal = maskData[idx];
            if(mVal != 0 && mVal != _m_id)
            {
                float d2 = 1.0f - depthData[idx];
                if(d2 < d)
                {
                    return true;
                }
            }
        }
        else
        {
            int xPos = xyPosData[2*idx];
            int yPos = xyPosData[2*idx+1];
            
            if(xPos < 0 || yPos < 0)
                return false;
            
            int idx2 = yPos*_roi.width + xPos;
            
            float DsdtDx2 = (sdtData[idx2 + 1] - sdtData[idx2 - 1])/2.0f;
            float DsdtDy2 = (sdtData[idx2 + _roi.width] - sdtData[idx2 - _roi.width])/2.0f;
            
            int xoffset = DsdtDx2 >= 0 ? 1 : -1;
            int yoffset = DsdtDy2 >= 0 ? 1*_roi.width : -1*_roi.width;
            
            if(xPos > 1 && xPos < _roi.width-2 && yPos > 1 && yPos < _roi.height-2)
            {
                // check pixel in x-offset direction
                uchar mVal = maskData[idx2 + xoffset];
                if(mVal != 0 && mVal != _m_id)
                {
                    float d2 = 1.0f - depthData[idx2 + xoffset];
                    if(d2 < d)
                    {
                        return true;
                    }
                }
                // check pixel in y-offset direction
                mVal = maskData[idx2 + yoffset];
                if(mVal != 0 && mVal != _m_id)
                {
                    float d2 = 1.0f - depthData[idx2 + yoffset];
                    if(d2 < d)
                    {
                        return true;
                    }
                }
                // check pixel in x- and y-offset direction
                mVal = maskData[idx2 + yoffset + xoffset];
                if(mVal != 0 && mVal != _m_id)
                {
                    float d2 = 1.0f - depthData[idx2 + yoffset + xoffset];
                    if(d2 < d)
                    {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }
    
    virtual void operator()( const cv::Range &r ) const
    {
		float wConfidence = 1.0f;
        int range = _roi.height/_threads;
        
        int jStart = r.start*range;
        if(r.start == 0)
            jStart = 1;
        
        int jEnd = r.end*range;
        if(r.end == _threads)
        {
            jEnd = _roi.height-1;
        }
        
        float* wJTJ = (float*)_wJTJCollection[r.start].val;
        float* JT = (float*)_JTCollection[r.start].val;
		float &wColor = _wColorCollection[r.start];
        
        float s = 1.2f;
        float s2 = s*s;
        
        for(int j = jStart; j < jEnd; j++)
        {
            float J[6];
            
            int idx = j*_roi.width + 1;
            
            for(int i = 1; i < _roi.width-1; i++, idx++)
            {
                float dist = sdtData[idx];
                
                if(fabs(dist) <= 8.0f)
                {
                    // the smoothed Heaviside value for this signed distance
                    float heaviside = 1.0f/float(CV_PI)*(-atan(dist*s)) + 0.5f;
                    
                    // the corresponding smoothed dirac delta value
                    float dirac = (1.0f / float(CV_PI)) * (s/(dist*s2*dist + 1.0f));
                    
                    // compute the average foreground and background posterior
                    // probablities from the given set of tclc-histograms
                    int pIdx = (j+_roi.y) * fullWidth + i+_roi.x;
                    
                    // compute the histogram bin index from the pixel's color
                    int ru = (frameData[3*pIdx] >> binShift);
                    int gu = (frameData[3*pIdx+1] >> binShift);
                    int bu = (frameData[3*pIdx+2] >> binShift);
                    
                    int binIdx = (ru * numBins + gu) * numBins + bu;
                    
                    float pYFVal = 0;
                    float pYBVal = 0;
					float pYFNotNormalizedVal = 0;
					float pYBNotNormalizedVal = 0;
                    
                    int cnt = 0;
                    
                    for(int h = 0; h < numHistograms; h++)
                    {
                        cv::Point3i centerID = centersIDs[h];
                        
                        if(initializedData[centerID.z])
                        {
                            // check whether the pixel is within the local histogram region
                            int dx = centerID.x - upscale*(i+_roi.x + 0.5f);
                            int dy = centerID.y - upscale*(j+_roi.y + 0.5f);
                            int distance = dx*dx + dy*dy;
                            
                            if(distance <= radius2)
							//if(1)
                            {
								//float pyf = getMeanPFromNearHistogram(centerID.z, ru, gu, bu, localFG);
								//float pyb = getMeanPFromNearHistogram(centerID.z, ru, gu, bu, localBG);
                                float pyf = localFG.at<float>(centerID.z, binIdx);
                                float pyb = localBG.at<float>(centerID.z, binIdx);

								pYFNotNormalizedVal += pyf;
								pYBNotNormalizedVal += pyb;
                                
                                pyf += 0.0000001f;
                                pyb += 0.0000001f;
                                
                                // compute local pixel-wise posteriors
                                pYFVal += pyf / (pyf + pyb);
                                pYBVal += pyb / (pyf + pyb);
                                
                                cnt++;
                            }
                        }
                    }
                    
                    if(cnt)
                    {
                        pYFVal /= cnt;
                        pYBVal /= cnt;
						pYFNotNormalizedVal /= cnt;
						pYBNotNormalizedVal /= cnt;
                    }

					pYFNotNormalizedVal += 0.0000001f;
					pYBNotNormalizedVal += 0.0000001f;
					wColor += wConfidence;
                    
                    // the energy inside the log
					float e = (heaviside * (pYFVal - pYBVal) + pYBVal) + 0.000001;
                    // the outer derivation
					float DlogeDe = -(pYFVal - pYBVal) / e;
                    // the constant part of the overall gradient for this image
                    float constant_deriv = DlogeDe*dirac;
                    
                    float x = _roi.x;
                    float y = _roi.y;
                    float D;
                    
                    int zIdx;
                    
                    // get the closest pixel on the contour for pixels in the background
                    if(dist > 0)
                    {
                        int xPos = xyPosData[2*idx];
                        int yPos = xyPosData[2*idx+1];
                        
                        // should not happen
                        if(xPos < 0 || yPos < 0)
                            continue;
                        
                        x += xPos;
                        y += yPos;
                        zIdx = yPos*_roi.width + xPos;
                    }
                    else
                    {
                        x += i;
                        y += j;
                        zIdx = idx;
                    }
                    
                    // get the depth buffer value for this pixel
                    float depth = 1.0f - depthData[zIdx];
                    
                    // check for occlusions in case of multiple objects
                    if(maskAvailable && isOccluded(idx, dist, depth))
                        continue;
                    
                    // compute the Z-distance to the camera from the depth buffer value
                    D = 2.0f * _zNear * _zFar / (_zFar + _zNear - (2.0f*depth - 1.0) * (_zFar - _zNear));
                    
                    // back-project to camera coordinates
                    float X_c = D*(K_invData[0]*x+K_invData[2]);
                    float Y_c = D*(K_invData[4]*y+K_invData[5]);
                    float Z_c = D;
                    float Z_c2 = Z_c*Z_c;

					// convert Coord_cam to Coord_objC
					float X_objC = _matTrans(0, 0)*X_c + _matTrans(0, 1)*Y_c + _matTrans(0, 2)*Z_c + _matTrans(0, 3);
					float Y_objC = _matTrans(1, 0)*X_c + _matTrans(1, 1)*Y_c + _matTrans(1, 2)*Z_c + _matTrans(1, 3);
					float Z_objC = _matTrans(2, 0)*X_c + _matTrans(2, 1)*Y_c + _matTrans(2, 2)*Z_c + _matTrans(2, 3);
					float Z_objC2 = Z_objC*Z_objC;

                    // the image gradient of the signed distance transform
                    float DsdtDx = (sdtData[idx + 1] - sdtData[idx - 1])/2.0f;
                    float DsdtDy = (sdtData[idx + _roi.width] - sdtData[idx - _roi.width])/2.0f;

					float interA, interB, interC, interC2;
					Matx12f matDstDx;
					matDstDx(0, 0) = DsdtDx;
					matDstDx(0, 1) = DsdtDy;

					Matx23f matDxDX;
					interA = _matTransInv(0, 0)*X_objC + _matTransInv(0, 1)*Y_objC + _matTransInv(0, 2)*Z_objC + _matTransInv(0, 3);
					interB = _matTransInv(1, 0)*X_objC + _matTransInv(1, 1)*Y_objC + _matTransInv(1, 2)*Z_objC + _matTransInv(1, 3);
					interC = _matTransInv(2, 0)*X_objC + _matTransInv(2, 1)*Y_objC + _matTransInv(2, 2)*Z_objC + _matTransInv(2, 3);
					interC2 = interC*interC;

					matDxDX(0, 0) = ((_fx*_matTransInv(0, 0) + _cx*_matTransInv(2, 0))* interC - (_fx*interA + _cx*interC)*_matTransInv(2, 0)) / interC2;
					matDxDX(0, 1) = ((_fx*_matTransInv(0, 1) + _cx*_matTransInv(2, 1))* interC - (_fx*interA + _cx*interC)*_matTransInv(2, 1)) / interC2;
					matDxDX(0, 2) = ((_fx*_matTransInv(0, 2) + _cx*_matTransInv(2, 2))* interC - (_fx*interA + _cx*interC)*_matTransInv(2, 2)) / interC2;
					matDxDX(1, 0) = ((_fy*_matTransInv(1, 0) + _cy*_matTransInv(2, 0))* interC - (_fy*interB + _cy*interC)*_matTransInv(2, 0)) / interC2;
					matDxDX(1, 1) = ((_fy*_matTransInv(1, 1) + _cy*_matTransInv(2, 1))* interC - (_fy*interB + _cy*interC)*_matTransInv(2, 1)) / interC2;
					matDxDX(1, 2) = ((_fy*_matTransInv(1, 2) + _cy*_matTransInv(2, 2))* interC - (_fy*interB + _cy*interC)*_matTransInv(2, 2)) / interC2;

					float arrayDXDxi[18] = { 0.0f, Z_objC, -Y_objC, 1.0f, 0.0f, 0.0f,
						-Z_objC, 0.0f, X_objC, 0.0f, 1.0f, 0.0f,
						Y_objC, -X_objC, 0.0f, 0.0f, 0.0f, 1.0f };
					cv::Matx<float, 3, 6> matDXDxi(arrayDXDxi);

					cv::Matx16f matJ;
					matJ = matDstDx*matDxDX*matDXDxi;
					J[0] = matJ(0, 0);
					J[1] = matJ(0, 1);
					J[2] = matJ(0, 2);
					J[3] = matJ(0, 3);
					J[4] = matJ(0, 4);
					J[5] = matJ(0, 5);
                    
                    // compute and add the per pixel gradient
                    for (int n = 0; n < 6; n++)
                    {
						JT[n] += wConfidence*constant_deriv*J[n];
                    }
                    
                    float c2 = constant_deriv*constant_deriv;
                    
                    // compute the weighting term for this pixel
                    float w = -1.0f/log(e);
                    
                    // compute and add the per pixel Hessian approximation
                    for (int n = 0; n < 6; n++)
                    {
                        for (int m = n; m < 6; m++)
                        {
							wJTJ[n * 6 + m] += wConfidence*wConfidence*w*J[n] * c2*J[m]; //04.27
                        }
                    }
                    
                    // do the same for the inverse depth buffer
                    depth = 1.0f - depthInvData[zIdx];
                    
                    D = 2.0f * _zNear * _zFar / (_zFar + _zNear - (2.0f*depth - 1.0) * (_zFar - _zNear));
                    
                    X_c = D*(K_invData[0]*x+K_invData[2]);
                    Y_c = D*(K_invData[4]*y+K_invData[5]);
                    Z_c = D;
                    Z_c2 = Z_c*Z_c;

					X_objC = _matTrans(0, 0)*X_c + _matTrans(0, 1)*Y_c + _matTrans(0, 2)*Z_c + _matTrans(0, 3);
					Y_objC = _matTrans(1, 0)*X_c + _matTrans(1, 1)*Y_c + _matTrans(1, 2)*Z_c + _matTrans(1, 3);
					Z_objC = _matTrans(2, 0)*X_c + _matTrans(2, 1)*Y_c + _matTrans(2, 2)*Z_c + _matTrans(2, 3);
					Z_objC2 = Z_objC*Z_objC;

					interA = _matTransInv(0, 0)*X_objC + _matTransInv(0, 1)*Y_objC + _matTransInv(0, 2)*Z_objC + _matTransInv(0, 3);
					interB = _matTransInv(1, 0)*X_objC + _matTransInv(1, 1)*Y_objC + _matTransInv(1, 2)*Z_objC + _matTransInv(1, 3);
					interC = _matTransInv(2, 0)*X_objC + _matTransInv(2, 1)*Y_objC + _matTransInv(2, 2)*Z_objC + _matTransInv(2, 3);
					interC2 = interC*interC;

					matDxDX(0, 0) = ((_fx*_matTransInv(0, 0) + _cx*_matTransInv(2, 0))* interC - (_fx*interA + _cx*interC)*_matTransInv(2, 0)) / interC2;
					matDxDX(0, 1) = ((_fx*_matTransInv(0, 1) + _cx*_matTransInv(2, 1))* interC - (_fx*interA + _cx*interC)*_matTransInv(2, 1)) / interC2;
					matDxDX(0, 2) = ((_fx*_matTransInv(0, 2) + _cx*_matTransInv(2, 2))* interC - (_fx*interA + _cx*interC)*_matTransInv(2, 2)) / interC2;
					matDxDX(1, 0) = ((_fy*_matTransInv(1, 0) + _cy*_matTransInv(2, 0))* interC - (_fy*interB + _cy*interC)*_matTransInv(2, 0)) / interC2;
					matDxDX(1, 1) = ((_fy*_matTransInv(1, 1) + _cy*_matTransInv(2, 1))* interC - (_fy*interB + _cy*interC)*_matTransInv(2, 1)) / interC2;
					matDxDX(1, 2) = ((_fy*_matTransInv(1, 2) + _cy*_matTransInv(2, 2))* interC - (_fy*interB + _cy*interC)*_matTransInv(2, 2)) / interC2;

					float _arrayDXDxi[18] = { 0.0f, Z_objC, -Y_objC, 1.0f, 0.0f, 0.0f,
						-Z_objC, 0.0f, X_objC, 0.0f, 1.0f, 0.0f,
						Y_objC, -X_objC, 0.0f, 0.0f, 0.0f, 1.0f };
					cv::Matx<float, 3, 6> _matDXDxi(_arrayDXDxi);

					matJ = matDstDx*matDxDX*_matDXDxi;
					J[0] = matJ(0, 0);
					J[1] = matJ(0, 1);
					J[2] = matJ(0, 2);
					J[3] = matJ(0, 3);
					J[4] = matJ(0, 4);
					J[5] = matJ(0, 5);
                    
                    for (int n = 0; n < 6; n++)
                    {
                        //JT[n] += constant_deriv*J[n];
						JT[n] += wConfidence*constant_deriv*J[n];
                    }
                    
                    for (int n = 0; n < 6; n++)
                    {
                        for (int m = n; m < 6; m++)
                        {
							wJTJ[n * 6 + m] += wConfidence*wConfidence*w*J[n] * c2*J[m]; //04.27
                        }
                    }
                }
            }
        }
    }
};

#endif //OPTIMIZATION_ENGINE