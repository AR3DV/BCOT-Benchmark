/**
The implementation of the proposed joint optimization framework based on multi-view data.
Based on the precise result, we construct the BCOT benchmark.

Monocular tracking: Observed from another view, there is a large translation error.
Multi-view tracking: Observe precise result from another view.
**/


#include <QApplication>
#include <QThread>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <iomanip>
#include <fstream>

#include "object3d.h"
#include "pose_estimator6d.h"

using namespace std;
using namespace cv;

float get_errorR(cv::Matx33f R_gt, cv::Matx33f R_pred) {
	cv::Matx33f tmp = R_pred.t() * R_gt;
	float trace = tmp(0, 0) + tmp(1, 1) + tmp(2, 2);
	return acos((trace - 1) / 2) * 180 / 3.14159265;
}

float get_errort(cv::Vec3f t_gt, cv::Vec3f t_pred) {
	float l22 = pow(t_gt[0] - t_pred[0], 2) + pow(t_gt[1] - t_pred[1], 2) + pow(t_gt[2] - t_pred[2], 2);
	return sqrt(l22);
}

cv::Matx33f eulerXYZ2Rot(float x, float y, float z)
{
	cv::Matx33f R(1, 0, 0,
		0, 1, 0,
		0, 0, 1);

	x = x * CV_PI / 180;
	y = y * CV_PI / 180;
	z = z * CV_PI / 180;

	// Assuming the angles are in radians.
	float cx = cos(x);
	float sx = sin(x);
	float cy = cos(y);
	float sy = sin(y);
	float cz = cos(z);
	float sz = sin(z);

	float m00, m01, m02, m10, m11, m12, m20, m21, m22;

	m00 = cy*cz;
	m01 = -cy*sz;
	m02 = sy;
	m10 = cz*sx*sy + cx*sz;
	m11 = cx*cz - sx*sy*sz;
	m12 = -cy*sx;
	m20 = -cx*cz*sy + sx*sz;
	m21 = cz*sx + cx*sy*sz;
	m22 = cx*cy;

	R(0, 0) = m00; R(0, 1) = m01; R(0, 2) = m02;
	R(1, 0) = m10; R(1, 1) = m11; R(1, 2) = m12;
	R(2, 0) = m20; R(2, 1) = m21; R(2, 2) = m22;

	return R;
}

cv::Matx44f eulerXYZ2Tcm(cv::Vec6f euler) {

	Matx33f R = eulerXYZ2Rot(euler[0], euler[1], euler[2]);

	Matx44f T_cam;
	T_cam(0, 0) = R(0, 0);
	T_cam(0, 1) = R(0, 1);
	T_cam(0, 2) = R(0, 2);
	T_cam(1, 0) = R(1, 0);
	T_cam(1, 1) = R(1, 1);
	T_cam(1, 2) = R(1, 2);
	T_cam(2, 0) = R(2, 0);
	T_cam(2, 1) = R(2, 1);
	T_cam(2, 2) = R(2, 2);

	T_cam(0, 3) = euler[3];
	T_cam(1, 3) = euler[4];
	T_cam(2, 3) = euler[5];

	T_cam(3, 0) = 0;
	T_cam(3, 1) = 0;
	T_cam(3, 2) = 0;
	T_cam(3, 3) = 1.0;

	return T_cam;

}

// Euler rotation in XYZ format to rotation matrix
cv::Vec3f Rot2EulerXYZ(const cv::Matx33f &R)
{
	cv::Vec3f eulerxyz(0, 0, 0);

	if (R(0, 2)<1)
	{
		if (R(0, 2)>-1)
		{
			eulerxyz[1] = asin(R(0, 2));
			eulerxyz[0] = atan2(-R(1, 2), R(2, 2));
			eulerxyz[2] = atan2(-R(0, 1), R(0, 0));
		}
		else
		{
			eulerxyz[1] = -CV_PI / 2;
			eulerxyz[0] = -atan2(R(1, 0), R(1, 1));
			eulerxyz[2] = 0;
		}
	}
	else
	{
		eulerxyz[1] = CV_PI / 2;
		eulerxyz[0] = atan2(R(1, 0), R(1, 1));
		eulerxyz[2] = 0;
	}
	eulerxyz[1] = eulerxyz[1] * 180 / CV_PI;
	eulerxyz[0] = eulerxyz[0] * 180 / CV_PI;
	eulerxyz[2] = eulerxyz[2] * 180 / CV_PI;
	return eulerxyz;
}

cv::Mat drawResultOverlay(const vector<Object3D*>& objects, const cv::Mat& frame)
{
	// render the models with phong shading
	RenderingEngine::Instance()->setLevel(0);

	vector<Point3f> colors;
	colors.push_back(Point3f(1.0, 0.5, 0.0));
	//colors.push_back(Point3f(0.2, 0.3, 1.0));
	RenderingEngine::Instance()->renderShaded(vector<Model*>(objects.begin(), objects.end()), GL_FILL, colors, true);

	// download the rendering to the CPU
	Mat rendering = RenderingEngine::Instance()->downloadFrame(RenderingEngine::RGB);

	// download the depth buffer to the CPU
	Mat depth = RenderingEngine::Instance()->downloadFrame(RenderingEngine::DEPTH);

	// compose the rendering with the current camera image for demo purposes (can be done more efficiently directly in OpenGL)
	Mat result = frame.clone();
	for (int y = 0; y < frame.rows; y++)
	{
		for (int x = 0; x < frame.cols; x++)
		{
			Vec3b color = rendering.at<Vec3b>(y, x);
			if (depth.at<float>(y, x) != 0.0f)
			{
				result.at<Vec3b>(y, x)[0] = color[2];
				result.at<Vec3b>(y, x)[1] = color[1];
				result.at<Vec3b>(y, x)[2] = color[0];
			}
		}
	}
	return result;
}

cv::Mat drawResultOverlayLine(const vector<Object3D*>& objects, const cv::Mat& frame)
{

	RenderingEngine::Instance()->setLevel(0);
	RenderingEngine::Instance()->renderSilhouette(vector<Model*>(objects.begin(), objects.end()), GL_LINE);
	Mat mask = RenderingEngine::Instance()->downloadFrame(RenderingEngine::MASK);

	// compose the rendering with the current camera image for demo purposes (can be done more efficiently directly in OpenGL)
	Mat result = frame.clone();
	for (int y = 0; y < frame.rows; y++) {
		for (int x = 0; x < frame.cols; x++) {
			if (mask.at<uchar>(y, x) != 0) {
				result.at<Vec3b>(y, x)[0] = 255;
				result.at<Vec3b>(y, x)[1] = 0;
				result.at<Vec3b>(y, x)[2] = 255;
			}
		}
	}
	return result;
}

int main(int argc, char *argv[]) {

	QApplication a(argc, argv);

	int width = 640;
	int height = 480;

	// near and far plane of the OpenGL view frustum
	float zNear = 1;
	float zFar = 3000.0;

	// camera instrinsics
	Matx33f K = Matx33f(700.03f, 0.f, 320.f, 0.f, 700.03f, 240.f, 0.f, 0.f, 1.f);
	Matx14f distCoeffs = Matx14f(0.0f, 0.0f, 0.0f, 0.0f);

	// distances for the pose detection template generation
	vector<float> distances = { 5.0f, 10.0f, 15.0f };

	// your data path
	string rootPath = "E:/VSWorkspace/BCOT/data/render/";
	string camImgPath_1 = "cam1/";
	string camImgPath_2 = "cam2/";
	std::string posePath_1 = rootPath + "pose_cam1.txt";
	std::string posePath_2 = rootPath + "pose_cam2.txt";
	int startNum = 0;
	int endNum = 300;

	// get gtpose_1
	std::vector<std::vector<float>> gtPoses_1;
	std::ifstream gtPoseFile_1(posePath_1);
	if (!gtPoseFile_1.is_open()) {
		printf("Cannot read gt pose\n");
		return 0;
	}
	while (!gtPoseFile_1.eof() && gtPoseFile_1.peek() != EOF) {
		std::vector<float> p;
		for (int i = 0; i < 12; ++i) {
			float number;
			gtPoseFile_1 >> number;
			p.push_back(number);
		}
		gtPoses_1.push_back(p);
	}
	gtPoseFile_1.close();

	// get gtpose_2
	std::vector<std::vector<float>> gtPoses_2;
	std::ifstream gtPoseFile_2(posePath_2);
	if (!gtPoseFile_2.is_open()) {
		printf("Cannot read gt pose\n");
		return 0;
	}
	while (!gtPoseFile_2.eof() && gtPoseFile_2.peek() != EOF) {
		std::vector<float> p;
		for (int i = 0; i < 12; ++i) {
			float number;
			gtPoseFile_2 >> number;
			p.push_back(number);
		}
		gtPoses_2.push_back(p);
	}
	gtPoseFile_2.close();

	// convert gt1 to eulerXYZ_1.
	std::vector<cv::Vec6f> eulerXYZ_1;
	for (int i = 0; i < gtPoses_1.size(); ++i) {
		cv::Matx33f R;
		R(0, 0) = gtPoses_1[i][0];
		R(0, 1) = gtPoses_1[i][1];
		R(0, 2) = gtPoses_1[i][2];
		R(1, 0) = gtPoses_1[i][3];
		R(1, 1) = gtPoses_1[i][4];
		R(1, 2) = gtPoses_1[i][5];
		R(2, 0) = gtPoses_1[i][6];
		R(2, 1) = gtPoses_1[i][7];
		R(2, 2) = gtPoses_1[i][8];
		cv::Vec3f r;
		cv::Vec3f t(gtPoses_1[i][9], gtPoses_1[i][10], gtPoses_1[i][11]);
		r = Rot2EulerXYZ(R);
		cv::Vec6f tmpEulerXYZ(r[0], r[1], r[2], t[0], t[1], t[2]);
		eulerXYZ_1.push_back(tmpEulerXYZ);
	}

	// convert gt2 to eulerXYZ_2.
	std::vector<cv::Vec6f> eulerXYZ_2;
	for (int i = 0; i < gtPoses_2.size(); ++i) {
		cv::Matx33f R;
		R(0, 0) = gtPoses_2[i][0];
		R(0, 1) = gtPoses_2[i][1];
		R(0, 2) = gtPoses_2[i][2];
		R(1, 0) = gtPoses_2[i][3];
		R(1, 1) = gtPoses_2[i][4];
		R(1, 2) = gtPoses_2[i][5];
		R(2, 0) = gtPoses_2[i][6];
		R(2, 1) = gtPoses_2[i][7];
		R(2, 2) = gtPoses_2[i][8];
		cv::Vec3f r;
		cv::Vec3f t(gtPoses_2[i][9], gtPoses_2[i][10], gtPoses_2[i][11]);
		r = Rot2EulerXYZ(R);
		cv::Vec6f tmpEulerXYZ(r[0], r[1], r[2], t[0], t[1], t[2]);
		eulerXYZ_2.push_back(tmpEulerXYZ);
	}

	// save the optimized pose
	std::string optimizedPosesPath_1 = rootPath + "optimized_pose_cam1.txt";
	std::string optimizedPosesPath_2 = rootPath + "optimized_pose_cam2.txt";
	std::ofstream optimizedPoseFile_1(optimizedPosesPath_1);
	std::ofstream optimizedPoseFile_2(optimizedPosesPath_2);
	if (!optimizedPoseFile_1.is_open() || !optimizedPoseFile_2.is_open()) {
		printf("Cannot write optimized pose\n");
		return -1;
	}

	// load 3D objects_1
	vector<Object3D*> objects_1;
	string modelPath = rootPath + "cat.obj";
	objects_1.push_back(new Object3D(modelPath, eulerXYZ_1[startNum][3], eulerXYZ_1[startNum][4], eulerXYZ_1[startNum][5], eulerXYZ_1[startNum][0], eulerXYZ_1[startNum][1], eulerXYZ_1[startNum][2], 1.0, 0.55f, distances));

	// load 3D objects_2
	vector<Object3D*> objects_2;
	objects_2.push_back(new Object3D(modelPath, eulerXYZ_2[startNum][3], eulerXYZ_2[startNum][4], eulerXYZ_2[startNum][5], eulerXYZ_2[startNum][0], eulerXYZ_2[startNum][1], eulerXYZ_2[startNum][2], 1.0, 0.55f, distances));

	// create the pose estimator
	// notice K can be different in two estimator
	PoseEstimator6D* poseEstimator_1 = new PoseEstimator6D(width, height, zNear, zFar, K, distCoeffs, objects_1, 1);
	PoseEstimator6D* poseEstimator_2 = new PoseEstimator6D(width, height, zNear, zFar, K, distCoeffs, objects_2, 2);

	// active the OpenGL context for the offscreen rendering engine during pose estimation
	RenderingEngine::Instance()->makeCurrent();

	Mat frame_1, frame_2, result_1, result_2;
	int key = 0;

	for (int i = startNum; i < endNum; ++i) {

		// the image index in the render data begins from #1
		std::stringstream framePath_1;
		framePath_1 << rootPath << camImgPath_1 << "03_cat_Trans_StaticCamera1_" << std::setfill('0') << std::setw(4) << i + 1 << ".jpg";
		frame_1 = cv::imread(framePath_1.str(), 1);

		std::stringstream framePath_2;
		framePath_2 << rootPath << camImgPath_2 << "03_cat_Trans_StaticCamera2_" << std::setfill('0') << std::setw(4) << i + 1 << ".jpg";
		frame_2 = cv::imread(framePath_2.str(), 1);

		// start/stop tracking the first object
		if (i == startNum) {
			poseEstimator_1->toggleTracking(frame_1, 0, false);
			poseEstimator_2->toggleTracking(frame_2, 0, false);
		}

		vector<Mat> imagePyramid_1;
		Mat frameCpy_1;
		imagePyramid_1.push_back(frame_1);
		for (int l = 1; l < 4; l++) {
			resize(frame_1, frameCpy_1, Size(frame_1.cols / pow(2, l), frame_1.rows / pow(2, l)));
			imagePyramid_1.push_back(frameCpy_1);
		}

		vector<Mat> imagePyramid_2;
		Mat frameCpy_2;
		imagePyramid_2.push_back(frame_2);
		for (int l = 1; l < 4; l++) {
			resize(frame_2, frameCpy_2, Size(frame_2.cols / pow(2, l), frame_2.rows / pow(2, l)));
			imagePyramid_2.push_back(frameCpy_2);
		}

		// use GT pose to calculate T12
		// if the camera is fixed, this value should be same
		cv::Matx33f gt_R_1 = eulerXYZ2Rot(eulerXYZ_1[i][0], eulerXYZ_1[i][1], eulerXYZ_1[i][2]);
		cv::Vec3f gt_t_1(eulerXYZ_1[i][3], eulerXYZ_1[i][4], eulerXYZ_1[i][5]);
		Matx44f gt_T_1 = Matx44f::eye();
		for (int r = 0; r < 3; ++r) {
			for (int c = 0; c < 3; ++c) {
				gt_T_1(r, c) = gt_R_1(r, c);
			}
			gt_T_1(r, 3) = gt_t_1(r);
		}
		
		cv::Matx33f gt_R_2 = eulerXYZ2Rot(eulerXYZ_2[i][0], eulerXYZ_2[i][1], eulerXYZ_2[i][2]);
		cv::Vec3f gt_t_2(eulerXYZ_2[i][3], eulerXYZ_2[i][4], eulerXYZ_2[i][5]);
		Matx44f gt_T_2 = Matx44f::eye();
		for (int r = 0; r < 3; ++r) {
			for (int c = 0; c < 3; ++c) {
				gt_T_2(r, c) = gt_R_2(r, c);
			}
			gt_T_2(r, 3) = gt_t_2(r);
		} 
		Matx44f T12 = gt_T_2 * gt_T_1.inv();

		// this loop can cycle more to get more precise results
		for (int iter = 1; iter < 8; ++iter) {
			cv::Matx44f transCam2ObjC_1;
			cv::Matx44f transOjbC2Cam_1;
			cv::Matx44f transCam2ObjC_2;
			cv::Matx44f transOjbC2Cam_2;

			// the object center corrdinate frame is set at the center of the model, so it equals to T.inv()
			transCam2ObjC_1 = (objects_1[0]->getPose()).inv();
			transOjbC2Cam_1 = transCam2ObjC_1.inv();
			transCam2ObjC_2 = (objects_2[0]->getPose()).inv();
			transOjbC2Cam_2 = transCam2ObjC_2.inv();

			poseEstimator_1->estimatePoses(imagePyramid_1, false, false, true, iter, transCam2ObjC_1, transOjbC2Cam_1);
			poseEstimator_2->estimatePoses(imagePyramid_2, false, false, true, iter, transCam2ObjC_2, transOjbC2Cam_2);

			cv::Matx66f wJTJ_Inobj_1 = objects_1[0]->wJTJ_Inobj;
			cv::Matx66f wJTJ_Inobj_2 = objects_2[0]->wJTJ_Inobj;
			cv::Matx61f JT_Inobj_1 = objects_1[0]->JT_Inobj;
			cv::Matx61f JT_Inobj_2 = objects_2[0]->JT_Inobj;

			// single view
			//Matx61f delta_xi_1 = -wJTJ_Inobj_1.inv(DECOMP_CHOLESKY)*JT_Inobj_1;
			//Matx44f delta_xi_mat_1 = Transformations::exp(delta_xi_1);
			//Matx44f delta_xi_mat_InCam_1 = transOjbC2Cam_1*delta_xi_mat_1*transOjbC2Cam_1.inv();
			//objects_1[0]->setPose(delta_xi_mat_InCam_1*objects_1[0]->getPose());

			//Matx61f delta_xi_2 = -wJTJ_Inobj_2.inv(DECOMP_CHOLESKY)*JT_Inobj_2;
			//Matx44f delta_xi_mat_2 = Transformations::exp(delta_xi_2);
			//Matx44f delta_xi_mat_InCam_2 = transOjbC2Cam_2*delta_xi_mat_2*transOjbC2Cam_2.inv();
			//objects_2[0]->setPose(delta_xi_mat_InCam_2*objects_2[0]->getPose());

			// multi-view
			cv::Matx66f wJTJ_Inobj = 1.0*(wJTJ_Inobj_1 + wJTJ_Inobj_2);
			cv::Matx61f JT_Inobj = 1.0*(JT_Inobj_1 + JT_Inobj_2);
			Matx61f delta_xi = -wJTJ_Inobj.inv(DECOMP_CHOLESKY)*JT_Inobj;
			Matx44f delta_xi_mat = Transformations::exp(delta_xi);

			Matx44f delta_xi_mat_InCam_1 = transOjbC2Cam_1*delta_xi_mat*transOjbC2Cam_1.inv();
			objects_1[0]->setPose(delta_xi_mat_InCam_1*objects_1[0]->getPose());
			Matx44f delta_xi_mat_InCam_2 = transOjbC2Cam_2*delta_xi_mat*transOjbC2Cam_2.inv();
			objects_2[0]->setPose(delta_xi_mat_InCam_2*objects_2[0]->getPose());
		}

		// see in another view
		objects_2[0]->setPose(T12*objects_1[0]->getPose());
	
		result_1 = drawResultOverlayLine(objects_1, frame_1);
		imshow("frame_1", frame_1);
		imshow("result_1", result_1);

		result_2 = drawResultOverlayLine(objects_2, frame_2);
		imshow("frame_2", frame_2);
		imshow("result_2", result_2);
		key = waitKey(1);

		cv::Matx44f pred_T = objects_1[0]->getPose();
		optimizedPoseFile_1 << pred_T(0, 0) << "\t" << pred_T(0, 1) << "\t" << pred_T(0, 2) << "\t" <<
			pred_T(1, 0) << "\t" << pred_T(1, 1) << "\t" << pred_T(1, 2) << "\t" <<
			pred_T(2, 0) << "\t" << pred_T(2, 1) << "\t" << pred_T(2, 2) << "\t" <<
			pred_T(0, 3) << "\t" << pred_T(1, 3) << "\t" << pred_T(2, 3) << "\t" << "\n";
		pred_T = objects_2[0]->getPose();
		optimizedPoseFile_2 << pred_T(0, 0) << "\t" << pred_T(0, 1) << "\t" << pred_T(0, 2) << "\t" <<
			pred_T(1, 0) << "\t" << pred_T(1, 1) << "\t" << pred_T(1, 2) << "\t" <<
			pred_T(2, 0) << "\t" << pred_T(2, 1) << "\t" << pred_T(2, 2) << "\t" <<
			pred_T(0, 3) << "\t" << pred_T(1, 3) << "\t" << pred_T(2, 3) << "\t" << "\n";

		std::cout << "index:" << i + 1 << std::endl;
		// stop the demo
		if (key == 27)
			break;
	}


	// deactivate the offscreen rendering OpenGL context
	RenderingEngine::Instance()->doneCurrent();

	// clean up
	RenderingEngine::Instance()->destroy();

	for (int i = 0; i < objects_1.size(); i++) {
		delete objects_1[i];
	}
	objects_1.clear();
	for (int i = 0; i < objects_2.size(); i++) {
		delete objects_2[i];
	}
	objects_2.clear();

	delete poseEstimator_1;
	delete poseEstimator_2;
}
